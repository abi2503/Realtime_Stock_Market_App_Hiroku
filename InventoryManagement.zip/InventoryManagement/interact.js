const Web3 = require('web3');

// Instantiate web3 with the HTTP provider
const web3 = new Web3('http://localhost:7545');

// Check if the web3 object is properly created
console.log(web3);
// Contract ABI and Address
const ABI = [
    {
        "inputs": [],
        "stateMutability": "nonpayable",
        "type": "constructor"
    },
    {
        "inputs": [],
        "name": "owner",
        "outputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "name": "stockInventory",
        "outputs": [
            {
                "internalType": "string",
                "name": "ticker",
                "type": "string"
            },
            {
                "internalType": "uint256",
                "name": "quantity",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "averagePrice",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "costBasis",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "marketValue",
                "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "_id",
                "type": "uint256"
            },
            {
                "internalType": "string",
                "name": "_ticker",
                "type": "string"
            },
            {
                "internalType": "uint256",
                "name": "_quantity",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "_averagePrice",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "_costBasis",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "_marketValue",
                "type": "uint256"
            }
        ],
        "name": "addStockItem",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "_id",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "_quantity",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "_marketValue",
                "type": "uint256"
            }
        ],
        "name": "updateStockItem",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    }
];

const contractAddress = "0x65A71717B210e109c90eB9380660943EC6206920";
const contract = new web3.eth.Contract(ABI, contractAddress);

// Function to fetch data from the contract
async function checkData() {
    try {
        const item = await contract.methods.stockInventory(0).call();
        console.log('Stock Item:', item);
    } catch (error) {
        console.error('An error occurred:', error);
    }
}

// Execute the function to check data
checkData();
