const InventoryManagement = artifacts.require("InventoryManagement");

module.exports = function(deployer) {
  deployer.deploy(
    InventoryManagement,
    ["GE", "AMZN", "LC"],
    [10, 15, 15],
    [16416, 18621, 928],
    [164160, 279315, 13920],
    [164160, 279315, 13920]
  );
};
